package com.netormium.client.util;

import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordEnumeration;

/** Persistent bookmarks stored in MIDP RMS. */
public final class BookmarkStore {
    private static final String STORE = "NetormiumBookmarks";
    public static final class Bookmark {
        public String title, url;
        Bookmark(String t, String u) { title = t; url = u; }
    }
    public boolean add(String title, String url) {
        if (url == null || url.length() == 0) return false;
        RecordStore rs = null;
        try {
            rs = RecordStore.openRecordStore(STORE, true);
            RecordEnumeration en = rs.enumerateRecords(null, null, false);
            try {
                while (en.hasNextElement()) {
                    byte[] old = rs.getRecord(en.nextRecordId());
                    DataInputStream in = new DataInputStream(new ByteArrayInputStream(old));
                    in.readUTF();
                    if (url.equals(in.readUTF())) return true;
                }
            } finally { en.destroy(); }
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            DataOutputStream out = new DataOutputStream(bytes);
            out.writeUTF(title == null ? url : title);
            out.writeUTF(url);
            out.flush();
            byte[] data = bytes.toByteArray();
            rs.addRecord(data, 0, data.length);
            return true;
        } catch (Exception e) { return false; }
        finally { try { if (rs != null) rs.closeRecordStore(); } catch (Exception ignored) {} }
    }
    public Bookmark[] all() {
        java.util.Vector v = new java.util.Vector();
        RecordStore rs = null;
        try {
            rs = RecordStore.openRecordStore(STORE, true);
            RecordEnumeration en = rs.enumerateRecords(null, null, false);
            try {
                while (en.hasNextElement()) {
                    byte[] data = rs.getRecord(en.nextRecordId());
                    DataInputStream in = new DataInputStream(new ByteArrayInputStream(data));
                    v.addElement(new Bookmark(in.readUTF(), in.readUTF()));
                }
            } finally { en.destroy(); }
        } catch (Exception ignored) {}
        finally { try { if (rs != null) rs.closeRecordStore(); } catch (Exception ignored) {} }
        Bookmark[] out = new Bookmark[v.size()];
        v.copyInto(out);
        return out;
    }
}
